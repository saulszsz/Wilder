import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activosprew',
  templateUrl: './activosprew.component.html',
  styleUrls: ['./activosprew.component.css']
})
export class ActivosprewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
